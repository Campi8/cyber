const express = require('express');
const { engine } = require('express-handlebars');

const app = express();

// Configuração do Handlebars
app.engine('.handlebars', engine({ extname: '.handlebars'}));
app.set('view engine', 'handlebars');

// Rota principal
app.get('/', (req, res) => {
    res.send('Página Principal');
});

// Rota de login
app.get('/login', (req, res) => {
    res.send('login'); // Renderiza o arquivo login.handlebars
});

// Rota de main
app.get('/main', (req, res) => {
    res.send('main'); // Renderiza o arquivo login.handlebars
});

// Inicie o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
